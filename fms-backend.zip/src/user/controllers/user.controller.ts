import { Controller } from '@nestjs/common';
import { UserService } from '../user.service';

@Controller()
export class UserController {
  constructor(private userService: UserService) {}

  public getUserService(): UserService {
    return this.userService;
  }
}
